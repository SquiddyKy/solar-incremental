/*

* * * * * * * * * * * * *
*   SOLAR INCREMENTAL   *
* a solarpunk idle game *
*  created by Ky Letts  *
* * * * * * * * * * * * *

(Big thanks to YhvrTheSecond on Reddit for their amazing JavaScript tutorials)

*/

var gameData = {
    potato: 0,
    potatoPerClick: 1,
    potatoPerClickCost: 10,
    people: 0,
    peopleEfficiency: 1,
    peopleHunger:0.5,
    foodRequirement: 50,
    housingSpace: 4,
    lastTick: Date.now()
}

/* Game Loop Example, increases potato at approx. 1 per second
var mainGameLoop = window.setInterval(function() {
    diff = Date.now() - gameData.lastTick;
    gameData.lastTick = Date.now() //updates lastTick
    gameData.potato += gameData.potatoPerClick * (diff/1000)
    update("storedPotatoes", gameData.potato + " Potatoes in Storage")
}, 1000)
*/

//Villagers/Auto-clickers
var peopleLoop = window.setInterval(function() {
    //New People Arriving
    if (gameData.potato > gameData.foodRequirement && gameData.people < gameData.housingSpace) {
        if (confirm("A starving wanderer has come by, offering to help work your field in exchange for food. Let them stay?")){
            gameData.people++
            update("notifications", "The wanderer smiles and gets to work.")
        } else{
            update("notifications", "The wanderer trudges off into the wasteland.");
        }
        gameData.foodRequirement *= 2;
    }
    diff = Date.now() - gameData.lastTick;
    gameData.lastTick = Date.now(); //updates lastTick
    gameData.potato += gameData.peopleEfficiency * gameData.people * (diff/1000); //People Pulling Potatoes
    gameData.potato -= gameData.peopleHunger * gameData.people * (diff/1000); //People Eating Potatoes
    update("storedPotatoes", gameData.potato + " Potatoes in Storage");
}, 1000)


/* LEAVE OUT UNTIL YOU'VE FOUND A WAY TO CLEAR THE SAVE FILE (for the sake of testing)
//Save Game Stuff
var saveGameLoop = window.setInterval(function(){
    localStorage.setItem('SolarIncSave', JSON.stringify(gameData));
}, 60000)
var saveGame = JSON.parse(localStorage.getItem("SolarIncSave"));
if (saveGame !== null) {
    gameData = saveGame;
}
*/

/* Save Game Updates - One needed for each new variable added each update
if (typeof saveGame.VARIABLE !== "undefined") {
    gameData.VARIABLE = saveGame.VARIABLE;
}
*/


//Switches between different game tabs
function tab(tab) {
    document.getElementById("fieldsTab").style.display = "none";
    document.getElementById("craftTab").style.display = "none";
    document.getElementById(tab).style.display = "inline-block";
}
//SUPPOSEDLY Starts game in fields tab
//In actuality, does not
//Come back and fix this later
tab("fieldsTab");

//Update Element Content
function update(id, content) {
    document.getElementById(id).innerHTML = content;
}

/* LEAVE OUT UNTIL YOU'VE FOUND A WAY TO FORMAT EVERYTHING TO INT
/* Can't do much with half a potato, after all, nevermind 0.00002 of a potato
//Number Formatting
function format(number, type) {
    let exponent = Math.floor(Math.log10(number));
    let mantissa = number / (10**exponent);
    if (exponent < 3) return number.toFixed(1);
    if (type == "engineering") return ((10**exponent) % 3) * mantissa.toFixed(2) + "e" + (Math.floor(exponent/3) * 3);
    if (type == "scientific") return (mantissa.toFixed(2) + "e" + exponent);
}
*/

//Increases Stored Potatoes
function pullPotato() {
    gameData.potato += gameData.potatoPerClick;
    update("storedPotatoes", gameData.potato + " Potatoes in Storage");
}

//Increases Potatoes Per Click
function fertilisePotatoes() {
    if (gameData.potato >= gameData.potatoPerClickCost) {
        gameData.potato -= gameData.potatoPerClickCost;
        gameData.potatoPerClick += 1;
        gameData.potatoPerClickCost *= 2;
        update("storedPotatoes", gameData.potato + " Potatoes in storage");
        update("fertiliserPotatoes", gameData.potatoPerClick + " Fertiliser Used");
        //update("perClickUpgrade", "Fertilise Potatoes");
    }
    else {
        update("notifications", "You need " + (gameData.potatoPerClickCost - gameData.potato) + " more potatoes to do this.")// + document.getElementById("notifications").innerHTML;
    }
}